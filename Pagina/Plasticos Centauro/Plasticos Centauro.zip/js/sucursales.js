$( document ).ready(function() {
	// sucursal Matriz
    $("#sucursal-matriz").hover(function() {
    $(this).css("background-color","white");
    $(".parrafo").css("color","black");
    document.getElementById('imagen').src="img/Sucursal-Matriz.jpg";
  	}, function() {
    $(this).css("background-color","#004c83");
    $(".parrafo").css("color","white");
    document.getElementById('imagen').src="img/Sucursal-Matriz.jpg";
  	});
    // sucursal villa
  	$("#sucursal-villa").hover(function() {
    $(this).css("background-color","white");
    $(".parrafo-villa").css("color","black");
    document.getElementById('imagen').src="img/Sucursal-Fco-Villa.jpg";
  	}, function() {
    $(this).css("background-color","#004c83");
    $(".parrafo-villa").css("color","white");
    document.getElementById('imagen').src="img/Sucursal-Matriz.jpg";
  	});
  	// sucursal refugio
  	$("#sucursal-refugio").hover(function() {
    $(this).css("background-color","white");
    $(".parrafo-refugio").css("color","black");
    document.getElementById('imagen').src="img/Sucursal-Refugio.jpg";
  	}, function() {
    $(this).css("background-color","#004c83");
    $(".parrafo-refugio").css("color","white");
    document.getElementById('imagen').src="img/Sucursal-Matriz.jpg";
  	});
  	// sucursal lll
  	$("#sucursal-lll").hover(function() {
    $(this).css("background-color","white");
    $(".parrafo-lll").css("color","black");
    document.getElementById('imagen').src="img/Sucursal-III.jpg";
  	}, function() {
    $(this).css("background-color","#004c83");
    $(".parrafo-lll").css("color","white");
    document.getElementById('imagen').src="img/Sucursal-Matriz.jpg";
  	});
  	// sucursal-campo1
  	$("#sucursal-campo1").hover(function() {
    $(this).css("background-color","white");
    $(".parrafo-campo1").css("color","black");
    document.getElementById('imagen').src="img/Sucursal-Ex-Campo-I.jpg";
  	}, function() {
    $(this).css("background-color","#004c83");
    $(".parrafo-campo1").css("color","white");
    document.getElementById('imagen').src="img/Sucursal-Matriz.jpg";
  	});
  	// sucursal-campo2
  	$("#sucursal-campo2").hover(function() {
    $(this).css("background-color","white");
    $(".parrafo-campo2").css("color","black");
    document.getElementById('imagen').src="img/Sucursal-Ex-Campo-II.jpg";
  	}, function() {
    $(this).css("background-color","#004c83");
    $(".parrafo-campo2").css("color","white");
    document.getElementById('imagen').src="img/Sucursal-Matriz.jpg";
  	});
  	// sucursal-dolores
  	$("#sucursal-dolores").hover(function() {
    $(this).css("background-color","white");
    $(".parrafo-dolores").css("color","black");
    document.getElementById('imagen').src="img/Sucursal-Dolores.jpg";
  	}, function() {
    $(this).css("background-color","#004c83");
    $(".parrafo-dolores").css("color","white");
    document.getElementById('imagen').src="img/Sucursal-Matriz.jpg";
  	});
});